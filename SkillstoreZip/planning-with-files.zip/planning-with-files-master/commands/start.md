---
description: "Implements Manus-style file-based planning for complex tasks. Creates task_plan.md, findings.md, and progress.md. Use when starting complex multi-step tasks, research projects, or any task requiring >5 tool calls. Now with automatic session recovery after /clear"
disable-model-invocation: true
---

Invoke the planning-with-files:planning-with-files skill and follow it exactly as presented to you
