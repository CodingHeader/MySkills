# web-scrape

Intelligent web scraper with content extraction, multiple output formats, and error handling

---

## 📦 Downloaded from [Skillstore.io](https://skillstore.io)

This skill was downloaded from **AI Skillstore** — the official marketplace for Claude Code, Codex, and Claude skills.

🔗 **Skill Page**: [skillstore.io/skills/21pounder-web-scrape](https://skillstore.io/skills/21pounder-web-scrape)

## 🚀 Installation

### Via Claude Code Plugin System

```
/plugin marketplace add aiskillstore/marketplace
/plugin install 21pounder-web-scrape@aiskillstore
```

### Manual Installation

Copy the contents of this folder to your project's `.claude/skills/` directory.

## 📋 Skill Info

| Property | Value |
|----------|-------|
| **Name** | web-scrape |
| **Version** | 3.0.0 |
| **Author** | 21pounder |

### Supported Tools

- claude
- codex
- claude-code

## 🌐 Discover More Skills

Browse thousands of AI skills at **[skillstore.io](https://skillstore.io)**:

- 🔍 Search by category, tool, or keyword
- ⭐ Find verified, security-audited skills
- 📤 Submit your own skills to share with the community

---

*From [skillstore.io](https://skillstore.io) — AI Skills Marketplace*
