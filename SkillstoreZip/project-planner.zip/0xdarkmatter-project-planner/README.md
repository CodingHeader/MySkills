# project-planner

Detects stale project plans and suggests session commands. Triggers on: sync plan, update plan, check status, plan is stale, track progress, project planning.

---

## 📦 Downloaded from [Skillstore.io](https://skillstore.io)

This skill was downloaded from **AI Skillstore** — the official marketplace for Claude Code, Codex, and Claude skills.

🔗 **Skill Page**: [skillstore.io/skills/0xdarkmatter-project-planner](https://skillstore.io/skills/0xdarkmatter-project-planner)

## 🚀 Installation

Copy the contents of this folder to your project's `.claude/skills/` directory.

## 📋 Skill Info

| Property | Value |
|----------|-------|
| **Name** | project-planner |
| **Version** | 1.0.0 |
| **Author** | 0xDarkMatter |

### Supported Tools

- claude
- codex
- claude-code

## 🌐 Discover More Skills

Browse thousands of AI skills at **[skillstore.io](https://skillstore.io)**:

- 🔍 Search by category, tool, or keyword
- ⭐ Find verified, security-audited skills
- 📤 Submit your own skills to share with the community

---

*From [skillstore.io](https://skillstore.io) — AI Skills Marketplace*
